To run the project from menu: ./Chess +RTS -N8
To run the project from pre-loaded path: ./Chess pathComesHere +RTS -N8
To compile the project, incase needed: ghc -O2 -threaded --make Chess.hs